import tkinter as tk
from tkinter import ttk, messagebox
import json
import shutil
import os

# ==========================================
# 1. LÓGICA DA ÁRVORE BINÁRIA & CRIPTOGRAFIA
# ==========================================

class No:
    def __init__(self, palavra, pos_original):
        self.palavra = palavra
        self.pos_original = pos_original
        self.esquerda = None
        self.direita = None

class ArvoreBinaria:
    def __init__(self):
        self.raiz = None

    def inserir(self, palavra, pos_original):
        if not self.raiz:
            self.raiz = No(palavra, pos_original)
        else:
            self._inserir_recursivo(self.raiz, palavra, pos_original)

    def _inserir_recursivo(self, no, palavra, pos_original):
        # Inserção baseada na ordem alfabética das palavras para montar a BST
        if palavra.lower() < no.palavra.lower():
            if no.esquerda is None:
                no.esquerda = No(palavra, pos_original)
            else:
                self._inserir_recursivo(no.esquerda, palavra, pos_original)
        else:
            if no.direita is None:
                no.direita = No(palavra, pos_original)
            else:
                self._inserir_recursivo(no.direita, palavra, pos_original)

    # Percurso em Pré-Ordem (Raiz -> Esquerda -> Direita)
    def pre_ordem(self, no, lista):
        if no:
            lista.append({"pos": no.pos_original, "txt": no.palavra})
            self.pre_ordem(no.esquerda, lista)
            self.pre_ordem(no.direita, lista)

# Cifra de César Universal (+3)
def criptografar_texto(texto, chave=3):
    return "".join(chr(ord(c) + chave) for c in texto)

def descriptografar_texto(texto, chave=3):
    return "".join(chr(ord(c) - chave) for c in texto)


# ==========================================
# 2. INTERFACE GRÁFICA MULTI-TELA (TKINTER)
# ==========================================

class AppProtectNow:
    def __init__(self, root):
        self.root = root
        self.root.title("Protect Now - Sistema de Mensageria Segura")
        self.root.geometry("900x650")
        self.root.resizable(False, False)

        self.historico = []

        self.container = tk.Frame(self.root)
        self.container.pack(fill="both", expand=True)

        self.telas = {}

        try:
            self.fundo_img = tk.PhotoImage(file="FUNDO FULL.png")
        except:
            self.fundo_img = None

        for TelaClass in (TelaLogin, TelaEscrever, TelaLer, TelaCadastro):
            nome_tela = TelaClass.__name__
            frame = TelaClass(parent=self.container, controller=self)
            self.telas[nome_tela] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.mostrar_tela("TelaLogin")

    def mostrar_tela(self, nome_tela):
        frame = self.telas[nome_tela]
        if nome_tela == "TelaLer":
            frame.atualizar_historico_ui()
        frame.tkraise()


# ------------------------------------------
# TELA 1: LOGIN
# ------------------------------------------
class TelaLogin(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#071A3D")
        self.controller = controller

        if controller.fundo_img:
            lbl_fundo = tk.Label(self, image=controller.fundo_img)
            lbl_fundo.place(x=0, y=0, relwidth=1, relheight=1)

        painel = tk.Frame(self, bg="#071A3D", bd=2, relief="groove")
        painel.place(relx=0.5, rely=0.5, anchor="center", width=380, height=380)

        tk.Label(painel, text="PROTECT NOW", font=("Arial", 18, "bold"), bg="#071A3D", fg="white").pack(pady=15)

        tk.Label(painel, text="E-mail", font=("Arial", 10, "bold"), bg="#071A3D", fg="white").pack(anchor="w", padx=30)
        self.email_entry = tk.Entry(painel, font=("Arial", 11), width=30)
        self.email_entry.pack(pady=(0, 10), ipady=3)

        tk.Label(painel, text="Senha", font=("Arial", 10, "bold"), bg="#071A3D", fg="white").pack(anchor="w", padx=30)
        self.senha_entry = tk.Entry(painel, font=("Arial", 11), width=30, show="*")
        self.senha_entry.pack(pady=(0, 15), ipady=3)

        tk.Button(painel, text="Entrar", bg="#1677FF", fg="white", font=("Arial", 10, "bold"), width=25,
                  command=lambda: controller.mostrar_tela("TelaEscrever")).pack(pady=5, ipady=3)

        tk.Button(painel, text="Criar Conta", bg="#003A8C", fg="white", font=("Arial", 10, "bold"), width=25,
                  command=lambda: controller.mostrar_tela("TelaCadastro")).pack(pady=5, ipady=3)


# ------------------------------------------
# TELA 2: ESCREVER & CRIPTOGRAFAR (REMETENTE)
# ------------------------------------------
class TelaEscrever(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#F0F2F5")
        self.controller = controller

        bar = tk.Frame(self, bg="#071A3D", height=40)
        bar.pack(fill="x")
        tk.Button(bar, text="Escrever/Enviar", bg="#1677FF", fg="white", font=("Arial", 9, "bold")).pack(side="left", padx=10, pady=5)
        tk.Button(bar, text="Ler/Receber", bg="#003A8C", fg="white", font=("Arial", 9, "bold"),
                  command=lambda: controller.mostrar_tela("TelaLer")).pack(side="left", padx=5, pady=5)
        tk.Button(bar, text="Sair", bg="#FF4D4F", fg="white", font=("Arial", 9, "bold"),
                  command=lambda: controller.mostrar_tela("TelaLogin")).pack(side="right", padx=10, pady=5)

        tk.Label(self, text="Painel de Envio (Maricá -> Niterói)", font=("Arial", 14, "bold"), bg="#F0F2F5", fg="#071A3D").pack(pady=10)

        tk.Label(self, text="Digite qualquer mensagem curta:", font=("Arial", 10, "bold"), bg="#F0F2F5").pack(anchor="w", padx=20)
        self.txt_mensagem = tk.Text(self, font=("Arial", 11), height=4)
        self.txt_mensagem.pack(fill="x", padx=20, pady=5)

        btn_frame = tk.Frame(self, bg="#F0F2F5")
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="1. Gerar Árvore e Criptografar", bg="#1677FF", fg="white", font=("Arial", 10, "bold"),
                  command=self.processar_e_criptografar).pack(side="left", padx=5)

        tk.Button(btn_frame, text="2. Exportar para Pendrive", bg="#FA8C16", fg="white", font=("Arial", 10, "bold"),
                  command=self.upar_para_pendrive).pack(side="left", padx=5)

        tk.Label(self, text="Visualização da Árvore Criptografada (Saída em Pré-Ordem):", font=("Arial", 10, "bold"), bg="#F0F2F5").pack(anchor="w", padx=20)
        self.txt_resultado = tk.Text(self, font=("Arial", 11), height=5, bg="#E6F7FF")
        self.txt_resultado.pack(fill="x", padx=20, pady=5)

    def processar_e_criptografar(self):
        # 1. Pega EXATAMENTE a mensagem que o usuário digitou
        msg = self.txt_mensagem.get("1.0", tk.END).strip()
        if not msg:
            messagebox.showerror("Erro", "Digite uma mensagem primeiro.")
            return

        # 2. Apaga arquivos antigos para evitar resíduos de mensagens passadas
        for f in ["mensagem.dat", "pendrive_mensagem.dat"]:
            if os.path.exists(f):
                os.remove(f)

        # 3. Monta uma Árvore Binária do zero para esta mensagem
        palavras = msg.split()
        arvore = ArvoreBinaria()
        for idx, palavra in enumerate(palavras):
            arvore.inserir(palavra, idx)

        # 4. Extrai a travessia em Pré-Ordem
        lista_nos = []
        arvore.pre_ordem(arvore.raiz, lista_nos)

        # 5. Criptografa o texto de cada nó
        for no in lista_nos:
            no["txt"] = criptografar_texto(no["txt"])

        # 6. Exibe a estrutura criptografada na tela
        self.txt_resultado.delete("1.0", tk.END)
        self.txt_resultado.insert(tk.END, f"{lista_nos}")

        # 7. Salva a nova mensagem criptografada no arquivo local
        with open("mensagem.dat", "w", encoding="utf-8") as file:
            json.dump(lista_nos, file)

        messagebox.showinfo("Sucesso", f"Mensagem '{msg}' criptografada e convertida em Árvore Binária!")

    def upar_para_pendrive(self):
        if not os.path.exists("mensagem.dat"):
            messagebox.showerror("Erro", "Gere e criptografe uma mensagem antes de exportar.")
            return

        shutil.copy("mensagem.dat", "pendrive_mensagem.dat")
        messagebox.showinfo("Pendrive", "Mensagem copiada para o Pendrive (pendrive_mensagem.dat)!")
        self.txt_mensagem.delete("1.0", tk.END)


# ------------------------------------------
# TELA 3: LER & DESCRIPTOGRAFAR (DESTINATÁRIO)
# ------------------------------------------
class TelaLer(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#F0F2F5")
        self.controller = controller

        bar = tk.Frame(self, bg="#071A3D", height=40)
        bar.pack(fill="x")
        tk.Button(bar, text="Escrever/Enviar", bg="#003A8C", fg="white", font=("Arial", 9, "bold"),
                  command=lambda: controller.mostrar_tela("TelaEscrever")).pack(side="left", padx=10, pady=5)
        tk.Button(bar, text="Ler/Receber", bg="#1677FF", fg="white", font=("Arial", 9, "bold")).pack(side="left", padx=5, pady=5)
        tk.Button(bar, text="Sair", bg="#FF4D4F", fg="white", font=("Arial", 9, "bold"),
                  command=lambda: controller.mostrar_tela("TelaLogin")).pack(side="right", padx=10, pady=5)

        tk.Label(self, text="Painel de Recebimento / Leitura", font=("Arial", 14, "bold"), bg="#F0F2F5", fg="#071A3D").pack(pady=5)

        tk.Button(self, text="Carregar e Descriptografar do Pendrive", bg="#52C41A", fg="white", font=("Arial", 10, "bold"),
                  command=self.carregar_e_descriptografar).pack(pady=5)

        painel_duplo = tk.Frame(self, bg="#F0F2F5")
        painel_duplo.pack(fill="both", padx=15, pady=5, expand=True)

        # Lado Esquerdo: Mensagem Atual
        f_esquerda = tk.Frame(painel_duplo, bg="#F0F2F5")
        f_esquerda.pack(side="left", fill="both", expand=True, padx=5)
        tk.Label(f_esquerda, text="Última Mensagem Lida:", font=("Arial", 10, "bold"), bg="#F0F2F5").pack(anchor="w")
        self.txt_leitura = tk.Text(f_esquerda, font=("Arial", 10), height=10)
        self.txt_leitura.pack(fill="both", expand=True, pady=3)

        # Lado Direito: Histórico
        f_direita = tk.Frame(painel_duplo, bg="#F0F2F5")
        f_direita.pack(side="right", fill="both", expand=True, padx=5)
        tk.Label(f_direita, text="📜 Histórico de Mensagens:", font=("Arial", 10, "bold"), bg="#F0F2F5").pack(anchor="w")
        self.txt_historico = tk.Text(f_direita, font=("Arial", 10), height=10, bg="#FAFAFA")
        self.txt_historico.pack(fill="both", expand=True, pady=3)

    def carregar_e_descriptografar(self):
        arquivo_alvo = "pendrive_mensagem.dat" if os.path.exists("pendrive_mensagem.dat") else "mensagem.dat"

        if not os.path.exists(arquivo_alvo):
            messagebox.showerror("Erro", "Nenhum arquivo de mensagem novo encontrado no pendrive.")
            return

        try:
            with open(arquivo_alvo, "r", encoding="utf-8") as file:
                lista_cripto = json.load(file)

            # 1. Descriptografa os nós
            nos_descriptografados = []
            for item in lista_cripto:
                texto_limpo = descriptografar_texto(item["txt"])
                nos_descriptografados.append((item["pos"], texto_limpo))

            # 2. Reordena as palavras pelo índice original
            nos_descriptografados.sort(key=lambda x: x[0])
            mensagem_final = " ".join([no[1] for no in nos_descriptografados])

            # 3. Limpa o visor antigo e exibe o novo texto
            self.txt_leitura.delete("1.0", tk.END)
            self.txt_leitura.insert(tk.END, f"=== ARQUIVO LIDO ({arquivo_alvo}) ===\n\n")
            self.txt_leitura.insert(tk.END, f"Estrutura Criptografada (Pré-Ordem):\n{lista_cripto}\n\n")
            self.txt_leitura.insert(tk.END, "--------------------------------------------------\n")
            self.txt_leitura.insert(tk.END, f"MENSAGEM FINAL DESCRIPTOGRAFADA:\n\"{mensagem_final}\"\n")

            # 4. Adiciona ao Histórico sem repetir a última mensagem
            if mensagem_final:
                if not self.controller.historico or self.controller.historico[-1] != mensagem_final:
                    self.controller.historico.append(mensagem_final)
                    self.atualizar_historico_ui()

        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao ler o arquivo: {e}")

    def atualizar_historico_ui(self):
        self.txt_historico.delete("1.0", tk.END)
        if not self.controller.historico:
            self.txt_historico.insert(tk.END, "Nenhuma mensagem gravada no histórico.")
        else:
            for idx, msg in enumerate(self.controller.historico, 1):
                self.txt_historico.insert(tk.END, f"[{idx}] {msg}\n---\n")


# ------------------------------------------
# TELA 4: CADASTRO DE USUÁRIO
# ------------------------------------------
class TelaCadastro(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#071A3D")
        self.controller = controller

        painel = tk.Frame(self, bg="#071A3D")
        painel.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(painel, text="CRIAR CONTA", font=("Arial", 16, "bold"), bg="#071A3D", fg="white").pack(pady=10)

        tk.Label(painel, text="E-mail", bg="#071A3D", fg="white").pack()
        tk.Entry(painel, width=30).pack(pady=5)

        tk.Label(painel, text="Senha", bg="#071A3D", fg="white").pack()
        tk.Entry(painel, width=30, show="*").pack(pady=5)

        tk.Button(painel, text="Cadastrar", bg="#1677FF", fg="white",
                  command=lambda: [messagebox.showinfo("Sucesso", "Conta criada!"), controller.mostrar_tela("TelaLogin")]).pack(pady=10)
        tk.Button(painel, text="Voltar ao Login", bg="#FF4D4F", fg="white",
                  command=lambda: controller.mostrar_tela("TelaLogin")).pack()


if __name__ == "__main__":
    root = tk.Tk()
    app = AppProtectNow(root)
    root.mainloop()